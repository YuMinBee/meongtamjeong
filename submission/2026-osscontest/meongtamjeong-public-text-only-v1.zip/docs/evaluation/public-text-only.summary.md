# public-text-only 평가 요약

- 프로필: `public-text-only-v1`
- 고정 기준일: `2026-07-26`
- 검색 artifact: 1,516 vectors / 1,516 notices / 512 dimensions
- index SHA-256: `679bf196cb5d85426a7975b0cb235dbdc1f0c886d69eeae443ef7ead8e5e764e`
- metadata SHA-256: `5810b5e79f475b0d747e5d8e9b32a9e01f15c8369172afbb672ea74ebe447757`

## 프로필 적용 결과

| 검증 | 핵심 결과 | 상태 |
|---|---|---|
| 자연어 검색 (`hybrid_natural_graph`) | P@5 86.67%, nDCG@5 89.93%, Hit@5 100.00%, inactive 0.00% | PASS |
| 질의 강건성 | 48 variants, mean top-5 Jaccard 0.993056, Hit@5 100.00% | PASS |
| 근거 노출 | 300/300 fields evaluated, unknown 0 | PASS |
| 프로필 재정렬 계약 | 2/2 profiles changed top-1, unknown-neutrality failures 0 | PASS |
| 안전 계약 | 4/4 contracts passed | PASS |

검색 지표의 relevance는 `public-notice-appearance.v1` 규칙으로 공고의 명시 필드만 사용해 만든 silver label입니다.

## 적용 불가

- 독립 query holdout v2/v3는 full 멀티모달 artifact에 고정돼 이 프로필에는 적용하지 않으며 PASS로 세지 않습니다.
- 이 프로필에는 image/crop vector가 없으므로 held-out image retrieval은 N/A이며 PASS로 세지 않습니다.

## 해석 한계

- 검색 relevance는 공고의 명시 필드로 만든 결정적 silver label이며 사람의 입양 선호 평가가 아닙니다.
- 프로필 재정렬 결과는 고정 계약·민감도 시험이며 입양 적합성이나 최적 가중치의 증명이 아닙니다.
- 같은 tag의 증거를 결정적으로 유지하기 위해 latency, runtime, 생성 시각과 로컬 경로는 요약에서 제외합니다.
- 공고 상태는 고정 기준일 이후 바뀔 수 있으므로 연락 전 원문 공고에서 다시 확인해야 합니다.

## 재현 명령

`environment.release.yml` 환경과 이 ZIP의 canonical `data/` artifact에서 실행합니다.

```powershell
$referenceDate = (Get-Content docs/evaluation/public-text-only.summary.json | ConvertFrom-Json).reference_date
python scripts/evaluate_retrieval.py --index data/dog_faiss.index --metas data/dog_metas.json --json-out dist/public-text-evidence/retrieval.json --markdown-out dist/public-text-evidence/retrieval.md --reference-date $referenceDate --device cpu --warmup 0
python scripts/evaluate_query_robustness.py --index data/dog_faiss.index --metas data/dog_metas.json --json-out dist/public-text-evidence/query-robustness.json --markdown-out dist/public-text-evidence/query-robustness.md --reference-date $referenceDate --device cpu --no-warmup
python scripts/evaluate_exposure_representation.py --metas data/dog_metas.json --retrieval-report dist/public-text-evidence/retrieval.json --json-out dist/public-text-evidence/exposure.json --markdown-out dist/public-text-evidence/exposure.md
python scripts/evaluate_profile_reranking.py --metas data/dog_metas.json --json-out dist/public-text-evidence/profile.json --markdown-out dist/public-text-evidence/profile.md
python scripts/evaluate_safety_contract.py --metas data/dog_metas.json --json-out dist/public-text-evidence/safety.json --markdown-out dist/public-text-evidence/safety.md
python scripts/build_public_text_evaluation_summary.py --reports-dir dist/public-text-evidence --index data/dog_faiss.index --metas data/dog_metas.json --profile-marker data/release_profile.json
```
