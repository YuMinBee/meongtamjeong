# public-text-only-v1 release guide

## 목적과 비법률적 성격

이 프로필은 새 배포물의 공고 사진 관련 권리 노출을 최소화합니다. 권리 안전성이나
법적 이용 가능성을 판정하지 않습니다. 현재·과거 Git 원격 이력에 공개된 사진 및
사진 파생 artifact의 권리 상태나 회수 조치도 해결하지 않습니다.

## 결정론적 파생 계약

- source row는 `type=text`, `embedding_source=public_notice_text`여야 합니다.
- canonical 공개 공고 텍스트와 `desc_full`, SHA-256가 일치해야 합니다.
- 공고마다 검증된 text row가 정확히 하나 있어야 합니다.
- 출력은 1,516개 공고, 1,516개
  512차원 text vector입니다.
- metadata와 manifest source는 고정 allowlist 밖의 필드를 제거합니다.

## 런타임 계약

marker/index/metas SHA-256·vector count·dimension·metadata allowlist가 어긋나면
시작하지 않습니다. graph overlay, 원격 공고 사진, 사진 품질 점수와 공고
gallery/crop/audit route는 비활성화합니다. 사용자 업로드 이미지 검색은 유지하지만
공고 text vector와 비교하므로 full 시각 검색 품질을 주장하지 않습니다.

## 평가 해석

full 멀티모달 artifact에서 만든 retrieval·robustness·exposure·profile·safety·held-out
리포트는 이 ZIP에서 제외합니다. 특히 held-out image retrieval은 visual vector가 없는
프로필에 적용 불가(N/A)이며 PASS로 세지 않습니다. 공고 상태는 연락 전 원문에서
다시 확인해야 합니다.

대신 이 profile의 고정 index·metadata에서 release gate가 다시 계산한 안정 지표만
[public-text-only evaluation summary](evaluation/public-text-only.summary.md)에
결정론적으로 축약해 포함합니다. raw 리포트의 실행 시각·latency·로컬 경로는
포함하지 않으며, summary JSON의 artifact SHA-256가 canonical 데이터와 다르면
패키징이 실패합니다.

full artifact에 고정된 독립 query holdout v2/v3의 runner·입력·sidecar·리포트·테스트도
부분적으로 남기지 않고 모두 제외합니다. text-only 성능으로 재사용하거나 PASS로
세지 않습니다.

## 함께 배포하는 profile-neutral 도구

[공고 Provider Adapter](provider-adapter.md)와
[공식 포털 후보 탐색 파일럿](evaluation/PORTAL_CANDIDATE_SELECTION_PROTOCOL.md)은
검색 artifact 유형과 무관한 재사용 도구라 포함합니다. Provider 합성 fixture의 모든
URL은 연결 불가능한 `.invalid`이며 canonical 운영 metadata가 아닙니다. 포털 파일럿은
결과 없는 템플릿만 제공하며 실제 사람 자료나 성과를 포함하지 않습니다. 파일럿을
실행한다면 이 ZIP의 text-only index·metadata와 실행 commit을 첫 참여자 전에 새로
freeze해야 합니다.

GitHub URL을 출품물로 쓰려면 별도 text-only clean branch/repository를 만들거나
공고 사진·사진 파생 artifact의 재배포 범위를 서면으로 확인해야 합니다.
