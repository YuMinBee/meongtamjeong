# Contributing — public-text-only-v1

이 번들의 canonical index·metadata·manifest·profile marker를 직접 편집하지 마세요.
원본 저장소에서 `scripts/build_public_text_release.py`로 결정론적으로 다시 파생하고,
allowlist·provenance·canonical text/hash 검증 실패를 우회하지 않아야 합니다.

이 ZIP에는 profile-applicable 테스트만 남아 있으므로 `python -m pytest -q`를
실행합니다. 실제 CPU 경로는 다음 명령으로 확인합니다.

```powershell
python scripts/smoke_full_runtime.py --profile public-text-only --index data/dog_faiss.index --metas data/dog_metas.json --release-profile-marker data/release_profile.json
```

사진·원격 사진 URL·image/crop 벡터를 다시 넣는 변경은 이 배포 프로필의 범위를
벗어나며 full 프로필에서 별도로 검토해야 합니다.

Provider adapter와 결과 없는 공식 포털 파일럿 프로토콜은 profile-neutral 도구로
함께 배포합니다. 합성 provider fixture의 URL은 `.invalid`로 유지하고, 사람 파일럿의
원본 CSV나 결과를 source tree에 추가하지 마십시오. full artifact에 고정된 query
holdout v2/v3 runner·입력·리포트·테스트는 이 text-only ZIP의 성능 근거가 아니므로
의도적으로 제외합니다.
