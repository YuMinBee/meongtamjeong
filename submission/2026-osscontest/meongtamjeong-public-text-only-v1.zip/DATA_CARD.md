# Data Card — public-text-only-v1

이 문서는 이 압축 파일에 실제 포함된 `public-text-only-v1` artifact만 설명합니다.
공고 사진 관련 권리 노출을 줄이기 위한 배포 대안이며 법적 판단이 아닙니다.

- `data/dog_metas.json`: 활성 공고 1,516건에 대응하는
  allowlist 기반 공개 공고 텍스트 메타 1,516행
- `data/dog_faiss.index`: `public_notice_text` provenance를 검증한
  1,516개 text 벡터, 512차원
- `data/snapshot_manifest.json`: source 필드 allowlist와 파생 artifact 해시
- `data/release_profile.json`: 런타임 fail-closed 정책과 canonical SHA-256
- `data/public_text_release_report.json`: 선택·제외 건수와 검증 계약

canonical 운영 검색 artifact에는 사진 파일, 실제 원격 공고 사진 URL, image/crop
벡터, VLM·detector 속성, crop 경로와 사진 품질 점수를 포함하지 않습니다. 별도
provider 계약 fixture의 `.invalid` URL은 연결 불가능한 합성 예시이며 운영 메타가
아닙니다. 공고 상태와 연락처는 스냅샷 이후 달라질 수 있고, 품종 표기는 기관의
공고 표기이지 혈통 또는 행동 특성의 검증이 아닙니다.
