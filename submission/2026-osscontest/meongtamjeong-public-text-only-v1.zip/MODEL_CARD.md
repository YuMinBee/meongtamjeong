# Model Card — public-text-only-v1

이 배포본은 CLIP ViT-B/32의 512차원 공간에 저장된 공개 공고
텍스트 벡터 1,516개를 검색합니다. image/crop 벡터와 사진 품질
신호는 포함하거나 점수에 사용하지 않습니다.

사용자 업로드 이미지 API는 호환성을 위해 유지되지만 이미지 임베딩을 공고 텍스트
벡터와 비교하므로, full 멀티모달 인덱스의 사진 검색 성능을 이 배포본에 귀속하지
않습니다. 이 기능은 보호소 방문 전 외형 후보 탐색을 돕는 도구이며 입양 적합성,
성격, 공격성, 아동 친화성 또는 다른 동물과의 사회성을 판정하지 않습니다.

이 ZIP에서 제외된 full-profile 평가 수치는 이 text-only artifact의 성능 근거가
아닙니다. 재현 시 `release_profile.json`과 `/health`의 profile·modality를 먼저
확인해야 합니다.
