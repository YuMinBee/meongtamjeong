# 멍탐정 — public-text-only 배포본

이 압축 파일은 `public-text-only-v1` 프로필입니다. 공고 사진 관련 권리 노출을
줄이기 위한 배포 대안이며, 사진이나 데이터의 권리 상태가 안전하다는 법적 판단이
아닙니다.

## 포함된 검색 데이터

- 활성 공고 1,516건의 공개 공고 텍스트 벡터 1,516개
- 임베딩 차원 512
- 벡터 유형: `text`만 포함
- 메타데이터: 고정 allowlist를 통과한 공개 공고 텍스트 필드만 포함

공고 사진 파일, 사진/crop 벡터, 원격 공고 사진 URL, 사진 품질 점수, 샘플 사진과
그 출처 manifest는 포함하지 않습니다. 런타임에서도 로컬 graph overlay와 공고
사진·crop·image-audit 제공 경로를 닫습니다.

## 검색 범위와 한계

자연어 검색과 외형 프로필 재정렬은 텍스트 벡터와 공고의 명시 필드를 사용합니다.
사용자 업로드 이미지 검색 API는 호환성을 위해 유지되지만, 업로드 임베딩을 공고
텍스트 벡터와 비교합니다. 따라서 원본 full 프로필의 사진/crop 검색 품질이나 사진
품질 기반 재정렬 성능을 이 배포본의 성능으로 주장하지 않습니다. 성격·공격성·아동
친화성·다른 동물과의 사회성도 사진이나 품종만으로 추정하지 않습니다.

원본 full 프로필용 시각 평가 리포트는 이 번들과 입력 artifact가 달라 제외했습니다.
full 프로젝트와 평가 자료는 원 저장소에서 별도로 확인해야 합니다:
https://github.com/YuMinBee/meongtamjeong

이 text-only artifact에 직접 적용한 정량 결과와 silver-label 한계는
[public-text-only evaluation summary](docs/evaluation/public-text-only.summary.md)에
고정 index·metadata SHA-256와 함께 제공합니다. 실행 시각·latency·로컬 경로는 같은
tag의 증거를 흔들 수 있어 요약에서 제외했습니다.

세부 파생·검증 계약은 [public-text-only release guide](docs/public-text-only-release.md)를
참고하십시오.

## 프로필 독립 오픈소스 도구

- [공고 Provider Adapter](docs/provider-adapter.md): 다른 기관의 공개 공고를 같은
  상태 필터·정규화·동기화 경로에 연결합니다.
- [공식 포털 후보 탐색 파일럿](docs/evaluation/PORTAL_CANDIDATE_SELECTION_PROTOCOL.md):
  결과를 만들지 않는 사전 고정 프로토콜, 교차 배정과 CSV 템플릿을 제공합니다.

`data/examples/notice-provider.synthetic.json`도 계약 시험용으로 포함합니다. 그 안의
`.invalid` URL은 인터넷에서 연결될 수 없는 합성 문자열이며 실제 공고·사진 참조가
아닙니다. 위의 원격 사진 참조 제외 계약은 canonical 운영 검색 artifact인
`dog_metas.json`, `snapshot_manifest.json`, FAISS index에 적용됩니다. 사람 파일럿의
실제 참여자 자료나 결과는 이 ZIP에 포함하거나 성과로 주장하지 않습니다.

## 실행

Conda 환경을 활성화하고 루트에서 다음 값을 설정한 뒤 실행합니다.

```powershell
conda env create -f environment.release.yml
conda activate meongtamjeong-release
$env:APP_ENV = "contest"
$keyBytes = New-Object byte[] 32
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($keyBytes)
$rng.Dispose()
$env:API_KEY = [Convert]::ToBase64String($keyBytes)
$env:INDEX_PATH = "data/dog_faiss.index"
$env:METAS_PATH = "data/dog_metas.json"
$env:RELEASE_PROFILE_PATH = "data/release_profile.json"
$env:RELEASE_PROFILE = "public-text-only"
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

`GET /health`에서 `release_profile`, `vector_modalities`, 공고 사진 및 visual asset
경로 비활성화 상태를 확인할 수 있습니다. 공고 상태는 스냅샷 이후 바뀔 수 있으므로
연락 전 실제 공고 링크에서 다시 확인해야 합니다.

```powershell
curl.exe -H "x-api-key: $env:API_KEY" http://127.0.0.1:8000/health
```

이 ZIP에서 유지한 profile-applicable 테스트와 실제 런타임 smoke는 다음 명령으로
검증합니다.

```powershell
python -m pytest -q
python scripts/smoke_full_runtime.py --profile public-text-only --index data/dog_faiss.index --metas data/dog_metas.json --release-profile-marker data/release_profile.json
```

이 프로필은 새 ZIP의 노출만 최소화합니다. 현재 또는 과거 Git 원격 이력에 이미
공개된 샘플 사진·사진 파생 인덱스의 권리 상태나 회수 조치를 해결하거나 판정하지
않습니다. GitHub URL 자체를 제출하려면 별도의 text-only clean branch/repository
또는 권리 확인이 필요합니다.
